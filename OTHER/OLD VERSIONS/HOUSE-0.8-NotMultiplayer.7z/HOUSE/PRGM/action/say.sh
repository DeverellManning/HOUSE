#!/bin/bash

ToMe=
ToYou=$(echo -e "$_name: \"$dirobj\"")

hear=$(find "$(_fwhere)" -iregex ".*\.char")

#echo "$hear"

_lineCount "$hear"

for line in $(seq 1 $(_lineCount "$hear")); do
	cl=$(_getLine "$hear" $line)
	cp=$(cat "$cl")
	#echo "$cp"
	echo "$ToYou">"$cp/mesg"
done
