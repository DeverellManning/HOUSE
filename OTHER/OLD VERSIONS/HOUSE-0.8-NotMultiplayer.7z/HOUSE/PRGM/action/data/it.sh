echo "Container:$_container"
echo "'it':     $_it"
echo "\$Item:    $Item"
echo "Holding:  $_hand"