#!/bin/sh
clear