#!/bin/bash

echo "Debug Messages will be shown."
_debug=true