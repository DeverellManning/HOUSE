#!/bin/sh
bash