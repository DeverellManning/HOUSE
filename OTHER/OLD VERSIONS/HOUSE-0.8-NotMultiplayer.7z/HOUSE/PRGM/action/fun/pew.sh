#!/bin/bash

	echo "Nneeooowww! Pew Pew Pew! Ping-^ WSHHHED kaPOW! BOOM BOOM."
	sleep 3
	echo "..."
	sleep 1.1
	echo -E ".\\\\........................."
	sleep 0.5
	echo -E "...\\\\................X......"
	sleep 0.5
	echo -E ".....\\\\.....oo.............."
	sleep 0.5
	echo -E ".......\\\\oOOOOOOo..........."
	sleep 0.5
	echo -E "..X......\\\\+OOOOOO.........."
	sleep 0.5
	echo ".........OO++OOOOOO....X....."
	sleep 0.5
	echo ".........OOOOOOOOOO.........."
	sleep 0.5
	echo -e "..........\`OOOOOO\`..........."
	sleep 0.5
	echo "......X.....^^^^............."
	sleep 0.5
	echo "............................."
	sleep 0.5
	echo "......................X......"
	sleep 0.5
	echo "..........X.................."
	sleep 0.5
	echo ".X.....................X....."
	sleep 1
	echo "          STAR WARS          "
	sleep 1
	echo "-----------------------------"
	sleep 1
	echo "Episode X: The Attack of Mall"
	sleep 1
	echo ""
	sleep 1
