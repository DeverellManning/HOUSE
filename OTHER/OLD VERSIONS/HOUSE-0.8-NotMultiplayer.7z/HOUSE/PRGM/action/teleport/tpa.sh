#!/bin/sh

echo WOPOOSHY
echo
echo "Nothing Happens."
return
echo "You just randomly teleport to Ardey!"
_where="/Eligotextum/Ardey/Town/Street"
clein
./PRGM/action/look.sh
