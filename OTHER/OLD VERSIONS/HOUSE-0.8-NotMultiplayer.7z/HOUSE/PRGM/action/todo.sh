#!/bin/bash
echo "Adding todo item:"
tonew="$_p1 $_p2"

echo "$tonew"

echo "$tonew" >> "./TODO.txt"

#$tonewecho 

#IF NOT "%TODOTEST%"=="-" (ECHO:>> ".\TODO.txt")
#ECHO:%TODO% >> ".\TODO.txt"
