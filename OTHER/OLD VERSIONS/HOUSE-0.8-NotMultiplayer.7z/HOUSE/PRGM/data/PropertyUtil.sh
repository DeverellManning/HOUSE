#!/bin/bash

qprop () {
	./PRGM/data/Qprop.sh "$1" "$2"
}
cprop () 
{
	./PRGM/data/Cprop.sh "$1"
}

#Bind an object to be
bind () {
	true	
}

unbind () {
true
}

set_prop () {
true
}

get_prop () {
true
}


reset_prop () {
true
}
