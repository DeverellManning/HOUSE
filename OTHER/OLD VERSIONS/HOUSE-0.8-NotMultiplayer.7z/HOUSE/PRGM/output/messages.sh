while [[ true ]]; do
	#Getting Ready
	#ctick=$()
	. "./PRGM/output/message-tick.sh";
	sleep 0.1
done