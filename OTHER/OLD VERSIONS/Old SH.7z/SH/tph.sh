#!/bin/sh

echo SWOOSHH
echo "You have teleported to a familiar place: The Master Bedroom"
_where="./WORLD/House/Second Floor/Master Bedroom"
clein
./PRGM/SH/look.sh
