#!/bin/sh

echo "FWOOSH"
echo "..."
echo "You pop into existence in..."
_where="./WORLD/Eligotextum/Start/S"
clein
./PRGM/SH/look.sh
