#!/bin/sh

echo WHOOSH
echo
echo "You teleport to the Kitchen!"
_where="./WORLD/House/First Floor/Kitchen"
clein
./PRGM/SH/look.sh
