#!/bin/sh

echo WHOOSH
echo
echo "You teleport to the stairs!"
_where="./WORLD/House/Stairs"
clein
./PRGM/SH/look.sh
