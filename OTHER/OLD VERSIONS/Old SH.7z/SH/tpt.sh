#!/bin/sh

echo WJHOOSPH
echo
echo "You teleport to the Trading Post!"
_where="./WORLD/Forest/North of House Section/Trading Post/Main Porch"
clein
./PRGM/SH/look.sh
