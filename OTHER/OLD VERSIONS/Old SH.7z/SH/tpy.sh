#!/bin/sh

echo SHOOOOFF!
sleep 1
echo pop!
echo "You teleported to the Back Yard!"
_where="./WORLD/Yard/Back/Middle North"
clein
./PRGM/SH/look.sh
