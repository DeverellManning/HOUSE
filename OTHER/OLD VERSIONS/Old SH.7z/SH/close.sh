#!/bin/sh

echo "You close the $_target."
#. ./$_where/$_target/close.sh
_target=
