#!/bin/bash

ppath="./DYNAMIC/Player/$idir"
mkdir "./DYNAMIC/Player/$idir"
mkdir "$ppath/ablities"

mkdir "$ppath/Clothes"
mkdir "$ppath/Clothes/Hat"
mkdir "$ppath/Clothes/Pants"
mkdir "$ppath/Clothes/Shirt"
mkdir "$ppath/Clothes/Shoes"

mkdir "$ppath/Inventory"

mkdir "$ppath/life"
mkdir "$ppath/looks"
mkdir "$ppath/personality"
mkdir "$ppath/stats"
mkdir "$ppath/Wallet"


echo -e "$Disc">"$ppath/Disc.txt"
echo -e"$Like">"$ppath/personality/Like.txt"
echo -e "$Dislike">"$ppath/personality/Dislike.txt"



echo "$MaxEnergy">"$ppath/Energy"
echo "$MaxWater">"$ppath/Water"
echo "$igender">"$ppath/Gender"
touch "$ppath/Hands"
touch "$ppath/Target"

echo "$start">"$ppath/Where"
#exit
echo "$iname">"$ppath/Name.txt"

echo "$ispec">"$ppath/Species"



#./ablities:
echo $cha >"$ppath/ablities/Charisma"
echo $dex >"$ppath/ablities/Dexterity"
echo $int >"$ppath/ablities/Inteligence"
echo $str >"$ppath/ablities/Strength"
echo $wis >"$ppath/ablities/Wisdom"

echo $speed >"$ppath/ablities/Speed"

#./life:
#Class
#Language
#Occupation

#./looks:
echo $ibuild>"$ppath/looks/Build"
. ./$SPath/Save.sh
#Looks.prop						- Done by SpeciesSave.sh or something

#./personality:
#ChromaName.txt

#./stats:
>"$ppath/stats/Air"
touch "$ppath/stats/Conditions"
echo "$HealSpeed">"$ppath/stats/HealSpeed"
echo "$MaxEnergy">"$ppath/stats/MaxEnergy"
echo "$MaxHealth">"$ppath/stats/MaxHealth"
echo "$MaxWater">"$ppath/stats/MaxWater"

echo "$baseH">"$ppath/stats/Height"
echo "$baseW">"$ppath/stats/Weight"
echo "$iSize">"$ppath/stats/Size"

echo "98">"$ppath/stats/Temprature"



#./Wallet:
echo "30">"$ppath/Wallet/Coins"
touch "$ppath/Wallet/Journal.txt"
