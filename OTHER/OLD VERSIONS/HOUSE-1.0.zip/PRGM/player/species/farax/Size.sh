#!/bin/sh

echo 3Medium
