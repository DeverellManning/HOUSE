#!/bin/bash

decho $PWD
confpath=./CONFIG
#Find Config File
if [[ ! -e "$confpath" ]]; then
	confpath=$(find ~/ -iregex ".*HOUSE/CONFIG$")
	if [[ ! -e "$confpath" ]]; then
		_serror "COULD NOT LOCATE CONFIG FILE."
	fi
fi

#Load Config
_conf=$(cat CONFIG)

#Read base path from config
_basepath=$(echo $_conf | jq -r .path)
decho "Basepath: $_basepath"
cd $_basepath


#Check for critical elements
if [[ ! -e "./PRGM" || ! -e "./EXPLORE.sh" ]]; then
	_serror "PRGM FOLDER or EXPLORE.SH MISSING"
fi

decho "$(ls)"



#Read and Evaluate Config File
decho "Loading config..."

#Path to Local World
_c_locworld=$(echo $_conf | jq -r ".local_world")

#Which World? (Online or Local)
_c_useworld=$(echo $_conf | jq  -r ".use_world")

#Can this client become master?
_c_canmaster=$(echo $_conf | jq -r ".can_become_master")

decho "Path to local world: $_c_locworld"
decho "use_world: $_c_useworld"
decho "Can become master (online): $_c_canmaster"

decho "Done loading."


#Check for Internet and Server availability
_server_available=false
if _check_internet; then
	if _check_server; then
		_server_available=true
	else
		echo "House Project Server is unavailable"
	fi	
else
	echo "Multiplayer does not work without internet."
fi



_worldchoice=online

#Evaluate world choice from config and
#Choose what world to connect to.
case $_c_useworld in
0)decho "0 - Default";;
1)decho "1 - Using local world."
	_worldchoice=local;;
2)decho "2 - Using Online world if available."
	if $_server_available; then
		_worldchoice=online
	else
		_worldchoice=local
	fi
	;;
3)decho "3 - Using Server world, if unavailable, abort."
	if $_server_available; then
		_worldchoice=online
	else
		_serror "Server is not available, aborting."
	fi
	;;
4)decho "4 - Asking what world to use."
	echo "What world are you connecting to?"
	read -p "(local/online)> " _choice
	if [[ ! $_choice =~ ^(local|online)$ ]]; then
		_serror "Choice not recognized.  Options are local and online. Choices are case-sensitive.  Please try again."
	fi
	_worldchoice=$_choice
	;;
esac
#decho "World Choice: $_worldchoice"




#Establish a rclone mount connection to the world.
_connection=false

#Disconnect if already connected
	umount ./WORLD
	umount ./SERVER

#Clear Folders
	rm -I ./SERVER/*
	rm -I ./WORLD/*

sleep 1

#The online world:
if [[ $_worldchoice == online ]]; then
	#Connect to online world
	decho "Connecting to online world."
	rclone mount --cache-dir ./OTHER/.cache/WORLD/\
		--vfs-cache-mode writes --dir-cache-time 2m --vfs-cache-poll-interval 10s  --vfs-cache-max-age 5m --vfs-write-back 2s\
		--log-file "./OTHER/LOG/mountS.log" --log-format=pid,time --log-level INFO\
		house-server:HOUSE/WORLD ./WORLD/ &
	_pid_world=$(jobs -p %+)


	rclone mount --cache-dir ./OTHER/.cache/SERVER/\
		--vfs-cache-mode writes --vfs-write-back 2s\
		--log-file "./OTHER/LOG/mountW.log" --log-format=pid,time --log-level INFO\
		house-server:HOUSE/SERVER ./SERVER/ &
	_pid_server=$(jobs -p %+)


	#rclone mount house-server:HOUSE ./WORLD && _connection=true &
fi

#The local world, as defined in CONFIG.local_world
if [[ $_worldchoice == local ]]; then
	#Connect to local world
	decho "Connecting to local world."
	rclone mount --cache-dir ./OTHER/.cache/WORLD/\
		--vfs-cache-mode writes --dir-cache-time 2m --vfs-cache-poll-interval 10s  --vfs-cache-max-age 5m --vfs-write-back 2s\
		--log-file "./OTHER/LOG/mountS.log" --log-format=pid,time --log-level INFO\
		$_c_locworld/WORLD ./WORLD/ &
	_pid_world=$(jobs -p %+)


	rclone mount --cache-dir ./OTHER/.cache/SERVER/\
		--vfs-cache-mode writes --vfs-write-back 2s\
		--log-file "./OTHER/LOG/mountW.log" --log-format=pid,time --log-level INFO\
		$_c_locworld/SERVER ./SERVER/ &
	_pid_server=$(jobs -p %+)


	
	#rclone mount --vfs-cache-mode full $_c_locworld/WORLD ./WORLD/ &
	#_connection=$?
	#rclone mount --vfs-cache-mode full $_c_locworld/SERVER ./SERVER/ &
	#_connection=$((_connection+$?))
fi

#Disconnect Command: umount ./WORLD

#Present PID's
echo "World Rclone PID:  $_pid_world"
echo "Server Rclone PID: $_pid_server"
#Check for Connection
if [[ -e ./WORLD && -e ./SERVER ]]; then
	decho "Conection Successful!"
	echo "Connected to $_worldchoice world."
	
else
	echo "Connection Unsuccsessful!"
	read -N1
	umount ./WORLD
	umount ./SERVER
	_serror "Not Connected!"

fi

_worldpath=./WORLD/ROOMS
_charpath=./WORLD/CHARACTERS

decho "Cleaning Up:"
unset _serror
unset _conf
unset _choice
unset confpath
decho "Done with Startup."
unset decho
