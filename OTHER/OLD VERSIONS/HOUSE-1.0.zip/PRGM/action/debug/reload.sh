#!/bin/bash

#Reload Utilities
. "./PRGM/data/PropertyUtil.sh"
. "./PRGM/utility/FilesUtil.sh"
. "./PRGM/utility/RandomUtil.sh"
. "./PRGM/utility/OutputUtil.sh"
. "./PRGM/utility/LineUtil.sh"
. "./PRGM/utility/CharacterInterationUtil.sh"


. "./PRGM/player/tick.sh" #Reload Player Ticking Functions
. "./PRGM/player/transactions.sh"

_fwhere () {
	echo "${_worldpath}${_where}"
}
