#!/bin/bash

echo "Debug Messages will be hidden."
_debug=false