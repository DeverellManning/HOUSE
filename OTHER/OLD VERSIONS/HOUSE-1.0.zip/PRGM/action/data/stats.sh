#!/bin/sh

echo "Health: $_health, Health Buffer: $_healthbuffer, Max Health: $_maxhealth"
echo "Energy: $_energy, Energy Buffer: $_energybuffer, Max Energy: $_maxenergy"
