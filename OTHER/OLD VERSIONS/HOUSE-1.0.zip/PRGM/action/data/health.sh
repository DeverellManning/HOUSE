#!/bin/sh
echo "You have $_health health."
