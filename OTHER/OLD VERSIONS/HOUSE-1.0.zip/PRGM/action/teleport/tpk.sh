#!/bin/sh

echo WHOOSH
echo
echo "You teleport to the Kitchen!"
_where="/House/First Floor/Kitchen"
clein
./PRGM/action/look.sh
