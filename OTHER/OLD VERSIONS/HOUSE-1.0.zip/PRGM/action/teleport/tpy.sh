#!/bin/sh

echo SHOOOOFF!
sleep 1
echo pop!
echo "You teleported to the Back Yard!"
_where="/Yard/Back/Middle North"
clein
./PRGM/action/look.sh
