#!/bin/sh

echo WJHOOSPH
echo
echo "Nothing Happens."
return
echo "You teleport to the Trading Post!"
_where="/Forest/North of House Section/Trading Post/Main Porch"
clein
./PRGM/action/look.sh
