. ./PRGM/action/drop.sh
