#!/bin/bash

decho -e "$ChromaDebugInventory Path: $ppath/Inventory/"
#echo "Checking Existence of Inventory..."

if [ -d $ppath/Inventory ]; then
	echo
	echo -e "$ChromaInventory[4m        Inventory        [0m"
	echo -e "${ChromaInventory}You are in possesion of: "
	echo -ne "$_coins Coins," | head -c10
	#echo -n " - Saved: "
	#cat "$ppath/Wallet/Coins"
	echo

	ls "./$ppath/Inventory" --quoting-style=literal -1 | sed -e "s/\.[^\.]*$//" | xargs -I {} echo "  {},"

	echo -e $ChromaDefault
	#echo "Done!(For Now)"
	
else 
	echo "$_ChromaDefault Oh No! Your inventory apparently DOESN'T EXIST! Do YOU even exist?!"
	sleep 1

fi

