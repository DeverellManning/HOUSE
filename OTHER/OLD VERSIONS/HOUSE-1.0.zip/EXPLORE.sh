#!/bin/bash

echo "Starting"

_debug=true

#Load Functions for Starting
. ./PRGM/utility/startfunc.sh
#Startup and login
. ./PRGM/start.sh


bd=	#?

#---VARS---

#Function
#SET "_return="

_gameversion="0.5"
_tty="$(tty)"
echo "$_tty"
#echo "$_tty">"./DYNAMIC/tty.id.txt"

##Parser
_ptest=false
_in=
_act=
_p1=
_p2=

#Colors
export ChromaTitle="\e[0m\e[4m\e[40m\e[95m"
export ChromaText="\e[0m"
export ChromaInventory="\e[0m\e[43m\e[37m\e[1m"
export ChromaDebug="\e[0m[1;31m[40m"
export ChromaError="\e[0m[1;31m[43m"
export ChromaDefault="\e[0m"

#Player
export ppath= #Player Path
export pname= #Player Folder Name

export _name=  #Player full name
export _sname= #Player short name
export _fwhere= #Path from HOUSE folder to where the player is.
export _where= 	#Path from HOUSE/WORLD/ROOMS to the player's location/
export _lastwhere=  
export _coins=
export _health=
export _target=

#History
hstloc=
hstmov=


#Time
export ttick=0
export tminute=0
export thour=0
export tDay=0

#Testing & Debuging
_sleep=0

#Load Utilities
. ./PRGM/action/debug/reload.sh

#Setup Traps
. ./PRGM/utility/TRAPS.sh


clein () {
	_act=
	_p1=
	_p2=
}

flush () {
	kill -SIGHUP $_pid_world $_pid_server
}


#Ticks the Client Once
GameTick() {
	if [[ ! $_sleep -gt 0 ]]; then echo -e "$ChromaDefault"; fi

	#Communicate with Server, then tell it to tick.
	echo -n "$_where">"$ppath/Where"
	
	echo -n "tick">"./SERVER/tick"
	sleep 0.1
	#Time
	flush
	ttickn=$(< "./WORLD/time")
	ttick=${ttickn:-$ttick}
	tminute=$(((ttick / 5)%30 * 2))
	thour=$((((ttick / 5) / 30)%24))
	tDay=$((((ttick / 5) / 30) / 24))

	#Player
	MainTick
	#TransactionTick
	#HealthTick
	#EnergyTick

	#Room Tree Ticking
	#local tw="$_where"
	#until [[ $tw = "." || $tw = "/" || ${tw:-null} = null ]]; do
	#	#echo "$tw/tick.sh"
	#	if [ -e "$tw/tick.sh" ]; then . "$tw/tick.sh"; fi
	#	tw=$(echo "$tw" | sed "s/\/[^\/]*$//")
	#done

	#Move "body"
	if [[ $_lastwhere != "$_where" ]]; then
		_target=
		if [[ -e ${_worldpath}${_lastwhere}/${_name}.char ]]; then
			mv "${_worldpath}${_lastwhere}/${_name}.char" "$(_fwhere)/${_name}.char"
		else
			echo "$ppath" > "$(_fwhere)/${_name}.char"
			echo "I fixed a problem with your body."
		fi
	fi
	
	#Check Player List
	if [[ ! $(grep -xF "$pname" "./SERVER/players") ]]; then
		echo "$pname" >> "./SERVER/players" #New line, on the end
	fi
	
	#Where Storage
	_lastwhere="$_where"
	

	#echo "Health: $_health, Health Buffer: $_healthbuffer, Max Health: $_maxhealth"
	#echo "Energy: $_energy, Energy Buffer: $_energybuffer, Max Energy: $_maxenergy"
	#echo "Time: $ttick - $tminute - $thour - $tDay"
	#echo "where: '$_where'"

	#if Sleeping/Skipping Turns, Skip Input
	if [ $_sleep -gt 0 ]; then
		#echo "Skip! $sleep"
		. "$_sleepc"
		_sleep=$((_sleep - 1))
		sleep 0.05
	else
	#Normal play, not sleeping:
		_sleep=0
		_sleepc=

		#Get Input		#read -rp"> " _act _p1 _p2
		echo -ne "\e[96m"
		read -erp"> " _in
		echo -e "\e[0m"
		
		#echo "$_in"
		if [ "$(echo "$_in" | tr "[:upper:]" "[:lower:]")" = "quit" ]; then
			echo "Type QUIT in upper case to quit, if you really want too."
		elif [ "${_in:-null}" = "null" ]; then
			return
		else
			#Run Parser
			. ./PRGM/parser/DirectClause.sh
			#. ./PRGM/parser/ActFind.sh #"$_act" "$_p1" "$_p2"		#This is important!
		fi
	fi

	#(Not Planned) Wait for other player...
	
}

StartMenu () {
	clear
	. ./PRGM/output/menu/StartMenu.sh
	
	_act=
	read -rp "Enter Name or Action:" _act
	_act=$(echo $_act | tr "[:upper:]" "[:lower:]")

	case "$_act" in
	q)
		echo "Goodbye."
		pause
		exit;;
		#Stop
	v)
		echo "Version: $_gameversion"
		echo "Press Enter"
		pause
		StartMenu;;
	n)
		echo New Character
		./PRGM/player/NewChar.sh
		sleep 2
		StartMenu;;
	c)
		echo "Change Log: WIP"
		##
		echo "Press Enter"
		pause
		StartMenu;;
	*)
		if [ -e "./WORLD/CHARACTERS/PLAYERS/$_act/Where" ]; then
			ppath="./WORLD/CHARACTERS/PLAYERS/"$_act
			pname=$_act
			. ./PRGM/player/LoadChar.sh

		else
			echo "./WORLD/CHARACTERS/PLAYERS/$_act/Where"
			echo "That character does not exist!"
			echo "Press Enter"
			pause
			StartMenu
		fi;;
	esac
	_act=
	_in=



}

Stop () {
	echo "QUITING"
	sleep 0.5
	kill "$_pid_messages"
	echo "Leaving Game..."

	#Remove name from players list
	echo "$(sed -e "s/$pname//g" ./SERVER/players | grep -vx "^$")" > ./SERVER/players
	
	echo "Saving Data..."
	. ./PRGM/player/SaveChar.sh
	sleep 0.5
	echo "Goodbye!  Come back any time!"
}


#___START HERE___#
while true; do
pause
StartMenu

clear
clein

. "./PRGM/player/tick.sh" #Load Player Ticking Functions
	
#script -a -O ./OTHER/HouseScript.log
_MASTERname=$(cat ./SERVER/master)
if [[ ${_MASTERname:-null} == null || $_MASTERname = $ppath ]]; then
	echo "$ppath" > "./SERVER/master"
	_MASTER=true
	#lxterminal -e "./PRGM/master/master.sh"
	lxterm -iconic -e "./PRGM/master/master.sh" &
	decho "This is the Master Proccess."
else
	_MASTER=false
	decho "$_MASTERname is hosting master."
fi

./PRGM/output/messages.sh &
_pid_messages=$(jobs -p %)
echo "Message Server PID: $_pid_messages"

echo "Welcome, $_name."
read -t 1
echo

. ./PRGM/action/data/where.sh
. ./PRGM/action/look.sh

until [ "$_in" = "QUIT" ];
do
	GameTick
done

#Player has Quit,
#Clean up and return to start menu.
Stop
#Really, these things should go in master.sh, but leave echo "END"
	if $_MASTER; then
		echo "END">"./SERVER/tick"
	fi
done
