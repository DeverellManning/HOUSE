#!/bin/bash
while [ true ]; do
	read -r -p"Name: " iname
	cp template.prop "./Unfinished/$iname.prop"
done
