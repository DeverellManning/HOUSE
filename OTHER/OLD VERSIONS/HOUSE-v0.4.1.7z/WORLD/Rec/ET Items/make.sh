#!/bin/bash
while [ true ]; do
	read -r -p"Name: " iname
	read -r -p"ID:   " id
	echo "Description: "
	read -r idisc

	echo -e "$id\n$idisc\n">"./$iname.txt"

done
