#!/bin/sh

type "$_ppath/Inventory/Juves Cracker Packer/Crackers.txt"

if [ -e "$_ppath/Inventory/Juves Cracker Packer/Crackers.txt" ]; then Refill;
else
	echo "You do not have a Juve's Cracker Packer, so it is impossible"
	echo: "for you to refill it with new crackers!"
	echo
	echo "Juve's Cracker Packers are sold at your local general store, supermarket, or trading post."
	pause
exit /b

Full () {
echo "Your Juve's Cracker Packer is Full, and you can't put any more crackers into it."
sleep 1
}


Refill () {
_size=9
echo "You have $( cat "$ppath/Inventory/Juves Cracker Packer/Crackers.txt" ) Crackers in your Juves Cracker Packer."

local Crackers=<"%_PPath%\Inventory\Juves Cracker Packer\Crackers.txt"
if [ $Crackers -ge 18 ]; then Full; fi

NewCount=$(( Crackers + _size ))
if [ $NewCount -ge 18 ];then
	NewCount=18
fi
echo $NewCount>"%_PPath%\Inventory\Juves Cracker Packer\Crackers.txt"

echo "Now you have ` cat "$ppath/Inventory/Juves Cracker Packer/Crackers.txt" ` crackers."
read var

#DEL "%~0"
}
