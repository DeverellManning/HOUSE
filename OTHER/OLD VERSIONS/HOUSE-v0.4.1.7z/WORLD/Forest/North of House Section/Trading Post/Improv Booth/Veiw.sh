#!/bin/sh

echo "  An unattended, simply-made shelf stands infront "
echo "of you, with a coin box hanging off the side. "
echo "Several items are on the shelf, each one with "
echo "a price tag directly below it."
echo
echo "There are Six items Total:"
echo "1. Juve's Cracker Packer      8¢"
echo "2. Juve's Crackers-18         4¢"
echo "3. Telescoping Tripod Stool  16¢"
echo "4. Broken Unicycle           28¢"
echo "5. Small Hiking Backback     20¢"
echo "6. Music Disc - Dimrain47    15¢"
echo

echo "Would you like to buy one?"
read  -p "(Yea or Nay)" ans

if [ $ans = "Yea" ]; then
. "./WORLD/Forest/North of House Section/Trading Post/Improv Booth/Buy.sh"
fi

