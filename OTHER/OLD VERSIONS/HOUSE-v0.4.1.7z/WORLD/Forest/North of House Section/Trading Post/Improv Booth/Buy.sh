#!/bin/sh

myloc="./WORLD/Forest/North of House Section/Trading Post/Improv Booth"
RESET () {
_icost=
_item=
_iname=
_boothmoney=
what=
#echo "DONE"
return
}

OutOfMoney () {
echo "You only have $_coins.  That is NOT enough!"
RESET
}



tptI1 () {
_icost=8
_item="Juves Cracker Packer"
_iname="Juve's Cracker Packer"
BuyIt
}

tptI2 () {
_icost=4
_item="Juves Cracker Packer Refill - 9.cmd"
_iname="Juve's Crackers"
BuyIt
}

tptI3 () {
_icost=16
_item=TS
_iname="Telescoping Tripod Stool"
BuyIt
}

tptI4 () {
_icost=28
_item="Broken Unicycle"
_iname="Broken Unicycle"
BuyIt
}

tptI5 () {
_icost=20
_item=HP
_iname="Small Hiking Backpack"
BuyIt
}

tptI6 () {
_icost=15
_item="Music Disk - At the Speed Of Light - Dimrain47.ref"
_iname="Music Disc - Dimrain47"
BuyIt
}

BuyIt  () {
	echo "You are buying a $_iname that costs $_icost coins."
	echo "Buying"
	
	_tc=$(( _coins-_icost ))
	if [ $_tc -lt 0 ]; then OutOfMoney; return; fi
	_coins=$_tc

	echo "$myloc/Shelf/$_item"
	echo "$ppath/Inventory"
	cp -r "$myloc/Shelf/$_item" "$ppath/Inventory/$_item"

	echo "You have $_coins left!"
	
	cat "$myloc/Coin Box/coins.txt"
	_boothMoney=`cat "$myloc/Coin Box/coins.txt"`
	_boothMoney=$((_boothMoney + _icost))
	echo $_boothMoney>"$myloc/Coin Box/coins.txt"

	#read var
	RESET
}



echo "You have $_coins coins.  What would you like to buy?"
read what

if [ "$what" = 1 ]; then tptI1
elif [ "$what" = 2 ]; then tptI2
elif [ "$what" = 3 ]; then tptI3
elif [ "$what" = 4 ]; then tptI4
elif [ "$what" = 5 ]; then tptI5
elif [ "$what" = 6 ]; then tptI6
else
echo "What do you mean, $what?"
return
fi

