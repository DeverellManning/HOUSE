#!/bin/bash
sleep 1
echo "Hello."
#pause
sleep 1
echo "You should not be here."
sleep .2
echo "You know that.  Right?"
sleep .3
read -p "> " var
sleep .2
echo "..."
sleep 1
echo "So.  I guess I've go to help you out now."
echo "Let me think.  This doesn't happen very often, you know."
read -p "> " var
sleep 1.2
echo "Okay! Ive got it..."
_where="./WORLD/Eligotextum/Wizard Tower/WT"

clein
. ./PRGM/action/look.sh
