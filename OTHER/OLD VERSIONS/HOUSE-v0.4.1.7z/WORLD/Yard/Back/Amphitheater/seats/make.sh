#!/bin/bash
while [ true ]; do
	read -r -p"Name: " iname
	read -r -p"ID:   " id
	#echo "Description: "
	#read -r idisc

	mkdir ./$id
	echo -e "$iname">"./$id/Name.txt"
	touch "./$id/Disc.txt"
	cp "./dir.door" "./$id/dir.door"

done
