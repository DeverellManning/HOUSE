#!/bin/bash
while [ true ]; do
	read -r -p"Name: " iname
	read -r -p"ID:   " id
	#echo "Description: "
	#read -r idisc

	mkdir ./$id
	echo -e "$iname">"./$id/Name.txt"
	touch "./$id/Disc.txt"
	echo -e "">"./$id/dir.door"

done

DOWN+./WORLD/Yard/Back/Amphitheater/seats/
UP+./WORLD/Yard/Back/Amphitheater/seats/
S+./WORLD/Yard/Back/Amphitheater/seats/
N+./WORLD/Yard/Back/Amphitheater/seats/