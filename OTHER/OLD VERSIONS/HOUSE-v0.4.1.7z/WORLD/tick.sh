#!/bin/bash

echo "$_where">"./DYNAMIC/p_where.txt"

