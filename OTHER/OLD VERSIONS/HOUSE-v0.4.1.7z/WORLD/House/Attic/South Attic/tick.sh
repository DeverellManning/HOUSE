#!/bin/bash
mod=$(( ttick % 5 ))

if [[ $mod -eq 3 ]]; then
echo "On the windowsill, something sparkles in the sun."
fi
