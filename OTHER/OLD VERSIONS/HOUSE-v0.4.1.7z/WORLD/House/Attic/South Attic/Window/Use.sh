echo "VIEW FROM WINDOW"
echo "Through the window, you can see"
echo "a wide veiw of the front yard's  "
echo "tall hedges, winding paths and "
echo "the deep forest beyond."

mod=$(( ttick % 5 ))
if [ $mod -eq 4 ]; then
echo
echo "There is a coin on the windowsill. Plink!"
 _coins=$(( _coins + 1 ))
fi