#!/bin/bash
echo "You sit down in the old chair."
pause
echo "You stand up, and the shelf creaks loudly."
cp "./WORLD/Rec/Healing Infusion.sh" "$_where/Shelf/"
