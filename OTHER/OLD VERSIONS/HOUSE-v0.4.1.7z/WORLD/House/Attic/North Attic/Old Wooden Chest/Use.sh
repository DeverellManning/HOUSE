#!/bin/bash
ls "$_where/Old Wooden Chest/"