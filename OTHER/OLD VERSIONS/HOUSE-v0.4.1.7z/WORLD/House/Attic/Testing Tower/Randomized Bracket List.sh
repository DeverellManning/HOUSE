#!/bin/bash

read -rp "Enter a bracket list: " list
echo "You said: '$list'"

bname=$(echo "$list" | grep -o "\[.*\]" | head -n1)
bresult="=&="
bresult="$(echo "$bname" | sed -e "s/\[\|\]//g" | sed -e "s/|/\n/g" )"
bresult="$(echo -e "$bresult" | shuf | head -n1)"

echo "$bname to $bresult"

list=$bresult

echo "'$list'"
