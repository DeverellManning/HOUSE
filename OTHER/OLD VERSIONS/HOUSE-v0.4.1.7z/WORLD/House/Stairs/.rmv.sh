#!/bin/sh
name=`echo $1|sed -e 's/\..*//'|tr [:upper:] [:lower:]`
type=`echo $1|sed -e 's/.*\.//'|tr [:upper:] [:lower:]`

if [ "$name" = "name" ];then exit; fi
if [ "$name" = "tick" ];then exit; fi
if [ "$name" = "veiw" ];then exit; fi
if [ "$name" = "veiwdown" ];then exit; fi
if [ "$name" = "veiwup" ];then exit; fi
if [ "$name" = "dir" ];then exit; fi
if [ "$type" = "char" ];then exit; fi
if [ `echo "$name" | cut -c 1` = "." ];then exit; fi
if [ "$type" = "door" ]; then exit; fi

mv "$(find "./WORLD/House/Stairs/$1")" "./WORLD/House/Attic/South Attic/Other Shelf"
