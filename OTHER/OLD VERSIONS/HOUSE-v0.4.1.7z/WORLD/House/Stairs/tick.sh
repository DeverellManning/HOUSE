#!/bin/sh
ls -x1QX --color=never "./WORLD/House/Stairs/"| xargs -n 1 ./WORLD/House/Stairs/.rmv.sh