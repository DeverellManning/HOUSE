echo "You look out the window in the master bedroom, and see"
