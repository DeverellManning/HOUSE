if [ "$_where" = "./WORLD/House/Second Floor/Master Bedroom" ]; then
mod=$(( ttick % 4 ))
if [ $mod -eq 0 ]; then echo "Tick"; fi
if [ $mod -eq 2 ]; then echo "Tock"; fi
fi

list=$(cat "./WORLD/House/Second Floor/Master Bedroom/Dresser/.ClothesList.txt")
dl=$(echo "$list" | awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}')

path=$(echo "$list" | head -n$(( $RANDOM % $dl )) | tail -n1)
if [[ -e $path ]]; then
	cp "$path" "./WORLD/House/Second Floor/Master Bedroom/Dresser/"
fi
