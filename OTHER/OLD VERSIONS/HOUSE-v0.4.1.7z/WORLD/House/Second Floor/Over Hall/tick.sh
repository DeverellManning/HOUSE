#!/bin/sh
if [ `shuf -i 1-6 -n 1` -eq 1 ]; then
	if [ `shuf -i 1-2 -n 1` -eq 1 ]; then
		echo "The metal floor creaks loudly."
	else
		echo "The cold, metal floor groans."
	fi
fi

