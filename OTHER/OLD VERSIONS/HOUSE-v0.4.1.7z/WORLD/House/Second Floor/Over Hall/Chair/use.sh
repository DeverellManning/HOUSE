#GENERIC SIT

echo "You sit in the chair."
IS_SIT=1
echo "Press enter to stand..."
read var
IS_SIT=0