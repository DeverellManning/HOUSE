#!/bin/bash
tsleep=$((_sleep / 6))
#echo "$tsleep - $_sleep"
if [[ $((_sleep % 6)) -ne 0 ]]; then
	return
else
case $tsleep in
0)
	if [[ $_sleepc = './WORLD/House/Second Floor/Master Bathroom/Shower/use.sh' ]]; then
		sleepc=
		sleep=0
		return
	fi
	if [ -f "$(find "$ppath/Clothes/Pants/" | head -n1)" ]; then
		echo "You're still clothed!  Who showers with clothes on?"
		read var
		if [ "$( echo "$var" | tr "[:upper:]" "[:lower:]" )" = "i do" ]; then
			echo "..."
			sleep 1
			echo "Okay?"
			sleep 0.5
			echo "Fine.  If you want to shower while wearing pants, go for it."
			sleep 1
		else
			echo "Right.  Now, try to take of your clothes FIRST,"
			sleep 0.5
			echo "then I'll let you in."
			sleep 0.4
			return
		fi
	fi
	sleep .4

	echo "	You turn on the water of the shower, and feel it with your "
	echo "$b_hand until it is warm.  Then you enter the shower, and "
	echo "pull closed the curtain.  You let the water fall down "
	echo "around nice and warm and steamy, making you relax and feel"
	echo "good about life.  You turn around so you're facing the water,"
	echo "and let is fall down on to your $b_face, washing away the dirt,"
	echo "as you close your $b_eyes.  It cleans off your $b_nose, and"
	echo "$b_ears, and filters down through your $b_hair."
	sleep 1
	_sleep=35
	_sleepc='./WORLD/House/Second Floor/Master Bathroom/Shower/use.sh'
	read var;;
5)
	echo "	You rest a bit, then grab the soap.  With it, you soap up"
	echo "your $b_hands and continue to wash your $b_skin.  The sensation"
	echo "is overwhelming, you feel as though there was nothing better to"
	echo "do than be showering in this shower.  You turn back forwards, "
	echo "and soap off your $b_chest.  Moving down, you soap up your"
	mix="$b_lower_body, and cover your $b_hips with the stuff.  You slather it "
	if [ "$b_fur_e" = true ]; then 
	mix="$b_lower_body, and smooth down your soaked $b_skin.  You slather it "
	fi
	echo "$mix"
	echo "down your $b_thighs, and around your knee.  Then on to your"
	echo "$b_ankles and $b_feet, and you take time to get in between every"
	echo "one of your $b_toes, soaping the cracks to release all the "
	echo "built-up grime."
	sleep 1
	read var;;
4)
	if [ "$b_tail_e" = true ]; then
	echo "	Then you move back up to your $b_waist, and start down your"
	echo "$b_tail.  You slip it through your $b_hands, and fill the $b_skin"
	echo "up with soap suds.  You squeeze and tug to get it distributed "
	echo "better, then give it a big hug just because.  Tails are "
	mix="wonderful, aren’t they?  You then return to your $b_arms, and "
	else
	mix="	Now to wash off your $b_arms, you start by lifting your arm to"
	fi
	echo "$mix"
	echo "soap up your $b_armpits.  Then the $b_shoulder and down to the "
	echo "$b_elbow.  After your $b_forearm is slathered in the stuff, you "
	echo "delicately wash your $b_hands and $b_fingers, cleaning of your "
	echo "$b_nails and polishing your $b_pawpads.  After this, you inspect"	#TODO: Add pawpad logic
	echo "the work you have accomplished.  You are covered in soap."
	sleep 1
	read var;;
3)
	echo "	So you turn and face the flow of water, and rub at your "
	echo "$b_skin to let the soap wash out, carrying the dirt and filth"
	echo "down the drain.  You feel clean and relieved.  Now you stand a"
	echo "little longer, letting the rinsing finish up, before you clean"
	if [ ${_look_hair_l:-2} -gt 3 ]; then
	echo "your $b_hair.  You pull your $b_fingers through your $b_hair,"
	echo "attempting to straighten it some what.  The you squirt some soap"
	echo "on your hand, and rub it on your $b_scalp, letting it flow down"
	echo "your hair on to your $b_shoulders.  The water drips off your "
	echo "$b_hair on to the tub, and it leads away the grease with it."
	else
	echo "your $b_hair.  You rub your $b_fingers around in your $b_hair, to"
	echo "rinse the soap off you head.  You straighten it with your $b_nails."
	fi
	echo "You move on to your $b_face, so you close your $b_eyes and turn"
	echo "your $b_head into the shower and allow the water spray it.  Then"
	echo "you mask it with the soap, rubbing it around your $b_ears and"
	echo "$b_eyes, before you rinse it one last time."
	sleep 1
	read var;;
2)
	echo "	Now you wait.  You’ve finished, but you don’t want to turn"
	echo "off the water yet.  It’s still nice and warm, and comfortable…"
	echo "You just like it and you want to stay."
	sleep 1
	read var;;
1)
	echo "	After a while, you turn up the water for a bit more heat,"
	echo "then turn it off completely.  The room is steamy and moist, "
	echo "keeping warm, but you rush for the towel to dry your self off,"	#TODO: Add  blow dryer for fur
	echo "before it gets cold.  You wipe the water off your $b_eyes and"
	echo "$b_face, working downwards.  You scrub at your $b_chest_f and "
	echo "$b_crotch, drying all of the $b_skin as best you can in the "
	echo "damp room.  Then you get your $b_legs and $b_feet, before "
	echo "hanging the towel around your $b_body and turning off the fan."
	sleep 2
	echo "You have completed showering." 
	sleep 3
	echo
	echo "You should probably get dressed now."
	sleep 3;;
esac
fi












