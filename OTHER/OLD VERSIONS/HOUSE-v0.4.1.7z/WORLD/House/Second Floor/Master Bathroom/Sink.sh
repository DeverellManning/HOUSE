#!/bin/bash

echo "Whoosh!"
sleep 0.5
echo "A stream of water comes out of the faucet, "
sleep 0.2
echo "and down into the drain pipe."
sleep 0.2
echo "You push the handle back to it's original position."
