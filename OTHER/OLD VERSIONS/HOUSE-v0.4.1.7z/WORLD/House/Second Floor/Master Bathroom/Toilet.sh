
echo "You sit down on the toilet, and ..."
echo "\e[31m--CENSORED--\e[0m"
sleep 1
echo "You stand up, and flush the toilet."
