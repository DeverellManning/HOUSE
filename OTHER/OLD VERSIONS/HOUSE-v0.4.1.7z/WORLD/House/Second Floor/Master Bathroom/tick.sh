#!/bin/bash

if [[ $((ttick % 4 )) -eq 0 && $(find "./WORLD/House/Second Floor/Master Bathroom/Towel Rack/" | awk 'BEGIN{c=0;}{c++}END{print c}') -lt 10 ]]; then
	cps "./WORLD/Rec/Clothing/towel.prop" "./WORLD/House/Second Floor/Master Bathroom/Towel Rack" > /dev/null
fi

if [[ $_where != "$_lastwhere" ]]; then
	out=$(find "./WORLD/House/Second Floor/Master Bathroom/Shower" -maxdepth 1 )
	out=$(echo "$out" | xargs -I {} ./PRGM/utility/filters/BasicFilter.sh '{}' | grep -o "[^/]*$" -- | sed -e "s/^\.//g" | sed -e "s/\..*$//g")
	echo -e "Inside the Shower: \n $out"
fi
