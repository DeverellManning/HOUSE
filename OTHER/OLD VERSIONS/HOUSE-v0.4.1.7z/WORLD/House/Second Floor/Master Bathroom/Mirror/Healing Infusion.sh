#@Disc
#A small bottle with a cork.  It has a thin, brownish liquid in it.
#@Prop
#`weight=1`
#`smell='It smells like wet leaves, but good.'`
#@end
echo "You lift the small, crystal vial to your lips,"
echo "and drink it in a gulp."
_health=$(( _health + 2 ))
echo "It tastes like leaves soaked in water."
