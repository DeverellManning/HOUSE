#!/bin/bash

echo "You Intently gaze at the Blue shelf, wondering what secrets it holds."
echo "Plink! Found a coin!"
_coins=$(( _coins + 1 ))