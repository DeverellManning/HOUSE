#!/bin/bash
echo -e "\e[0m\e[1m\e[34m  The blue bedroom is small, cozy, and VERY blue."
echo "The walls are painted blue, the bed has blue "
echo "covers, and a sky blue pillow lays on it.  The lumpy rug "
echo "is also blue, along with the shelf, light, curtains,"
echo "and just about every thing in the room. $chromaDefault"