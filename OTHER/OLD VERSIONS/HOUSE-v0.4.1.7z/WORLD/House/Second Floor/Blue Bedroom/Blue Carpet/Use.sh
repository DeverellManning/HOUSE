#!/bin/bash
echo You roll up the carpet to look under it, 
echo but find nothing but a blue floor.
