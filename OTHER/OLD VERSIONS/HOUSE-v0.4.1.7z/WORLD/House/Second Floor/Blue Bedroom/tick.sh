#!/bin/bash
bluetimer=$((bluetimer+1))
if [ $bluetimer -eq 6 ]; then
bluetimer=0
echo "BLUE!!"
fi
