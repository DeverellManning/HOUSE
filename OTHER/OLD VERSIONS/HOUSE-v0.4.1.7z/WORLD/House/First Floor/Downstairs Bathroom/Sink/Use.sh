#!/bin/bash
echo "You turn on the sink, causing a stream"
echo "of water to come out of the faucet."
echo "You then turn it off."