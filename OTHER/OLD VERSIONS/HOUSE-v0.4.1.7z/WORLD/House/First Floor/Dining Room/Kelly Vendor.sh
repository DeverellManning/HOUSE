#!/bin/bash
#@Prop
#@Interface
#`left=left`
#`right=right`
#`square=select`
#`enter=select`
#`select=select`
#`down=back`
#`back=back`
#@Disc
#It is a wooden box with a window.  Under the window, there are 
#several buttons: Two with arrows pointing left and right, one 
#with a square, and one with a arrow pointing down.  The Kelly
#Vendor is on a short stand.
#@End
echo -e "0: $0\n1: $1\n2: $2\n"

case $1 in
left)echo "left";;
right)echo "right";;
select)echo "select";;
back)echo "back";;
*)echo "unknown";;
esac
