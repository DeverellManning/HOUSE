#!/bin/bash
_target="./WORLD/House/First Floor/Standing Room/Bulletin Board"

echo "  The Bulletin Board  "
echo "The bulletin has some notes on it:"

Files1=$(find "$_target")
inam "$(echo "$Files1" | xargs -I {} -n1 ./PRGM/utility/filters/CompleteFilter.sh {})" | sort | sed -e "s/Bulletin Board//g" | xargs -I {} -n1 echo -e " - {}"