#!/bin/bash
. "./WORLD/House/First Floor/Standing Room/Bulletin Board/writ.sh"