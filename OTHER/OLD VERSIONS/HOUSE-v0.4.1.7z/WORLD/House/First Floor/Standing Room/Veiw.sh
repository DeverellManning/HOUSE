#!/bin/bash
if [ -e "./WORLD/House/First Floor/Standing Room/Bulletin Board/*" ]; then
	note_covered="A note covered"
else
	note_covered="An empty"
fi


echo "	It is very light here.  A large window allows the sun's "
echo "rays shine through.  A table, centered in the room, receives the"
echo "light in a dignified way.  You feel that this is a place to do "
echo "business.  To be cheerful, yet enterprising and diligent.  The "
echo "tall table is empty, and it looks like it can be used for a "
echo "meeting place."
echo "	A potted fern sits next to a bookshelf in one corner.  "
echo "The other is occupied by a matching fern, with a filing cabinet "
echo "and a wooden writing desk.  $note_covered bulletin hangs on the"
echo "wall opposite the window.  Hanging under it is a little wire "
echo "tray, holding paper notes and some pens.  A potted cactus with a"
echo "spout on it's base sits next to one door, and the other goes out"
echo "to the hall."