#GENERIC SIT

echo "You sit in the chair"
IS_SIT=1
echo "Press enter key to stand..."
read var