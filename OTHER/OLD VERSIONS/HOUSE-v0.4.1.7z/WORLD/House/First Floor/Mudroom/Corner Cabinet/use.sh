#!/bin/bash
echo "There is some music in this "
echo "cabinet.  Care to here it?"
read -N 1 -p "'Y'es or 'N'o" var
if [[ $var =~ [Yy] ]]; then
case $(rand 1 3) in
1)fp="./RESOURCE/music/Voxelbuffer.mp3";;
2)fp="./RESOURCE/music/Clan McCloud.mp3";;
3)fp="./RESOURCE/music/I Saw Three Ships (Instrumental).mp3";;
esac
cvlc --quiet --play-and-exit --no-interact "$fp" &
read -t 1
fi
