#!/bin/sh


. ./PRGM/utility/RandomUtil.sh

NewFood () {
	if [ $(rand 0 2) = 0 ]; then
		cps "$1" "./WORLD/House/First Floor/Pantry/Right Shelves/" > /dev/null
	else
		cps "$1" "./WORLD/House/First Floor/Pantry/Left Shelves/" > /dev/null
	fi
	if [ "$_where" = "./WORLD/House/First Floor/Pantry" ]; then
		echo "You hear a loud THUD from one of the shelves."
	fi
}

case $(rand 0 30) in
	1)NewFood "./WORLD/Rec/Foods/A Banana.prop";;
	2|5)NewFood "./WORLD/Rec/Foods/Apple.prop";;
	3)NewFood "./WORLD/Rec/Foods/Cabbage.prop";;
	4|6)NewFood "./WORLD/Rec/Foods/Carrot.prop";;
	*)return;; 
esac




