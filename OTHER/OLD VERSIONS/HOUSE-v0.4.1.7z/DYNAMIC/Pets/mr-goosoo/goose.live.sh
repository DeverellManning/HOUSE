#!/bin/bash

cd /home/deverell-manning/Public/HOUSE
me="./DYNAMIC/Pets/mr-goosoo"
_name="Mr Goosoo"

_ptty="$(cat ./DYNAMIC/tty.id.txt)"
echo "$_ptty"

. "./PRGM/data/PropertyUtil.sh"
. "./PRGM/utility/RandomUtil.sh"
. "./PRGM/utility/FilesUtil.sh"

. "./PRGM/npc/DoorUtil.sh"


#Messages
mHere () {
	echo "Mr. Goosoo is here."
}
mLeave () {
	echo "Mr. Goosoo waddles away."
}
mCome () {
	if [ ${_handname:-null} = null ]; then
		echo "Mr. Goosoo waddles up to you."
	else
		echo "The Butler enters the room, holding a $_handname."
	fi
}
mHold () {
	echo "The Butler takes a $_handname out of his pockets."
}
mUnhold () {
	echo "The Butler puts his $_handname back in his pockets."
}
mSleep () {
	echo "Mr. Goosoo falls asleep on the $sleepname."
}

mHereSleep () {
	echo "Mr. Goosoo is here, sleeping peacefully on the $sleepname."
}

echo "Welcome to Goose Live."
_where=$(cat "$me/Where")

echo "where: '$_where'"

if [ "$(cat "$me/ctick" | tr [:upper:] [:lower:])" = auto ]; then
	echo "AUTO GOOSE ENABLED."
	auto=t
else
	auto=f
fi
	

until [ "$Pin" = END ]
do
	Pin=$(cat "$me/ctick")

	echo "%$Pin%"


	if [[ "${Pin:-null}" = tick || "$auto" = t ]]; then
		echo -e "$Pin!"
		time . "$me/tick.sh"
	else
		echo -en "%"
	fi
	
	if [ "${message:-null}" != null ]; then
		echo "	'$message'"
		tput il1>"$_ptty"; echo -ne "\e[0m$message\e[0m">"$_ptty"; tput cud1>"$_ptty"; tput el>"$_ptty"; tput el1>"$_ptty"; tput hpa 0>"$_ptty"; echo -ne "\e[96m> ">"$_ptty"
	fi
	message=

	sleep 2
done

echo "Saving:"

echo "$_where">"$me/Where"

