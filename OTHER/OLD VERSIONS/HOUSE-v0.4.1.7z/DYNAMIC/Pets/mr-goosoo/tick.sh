#!/bin/bash

#Actions

Wait () {
	echo "Waiting..."
	message=
}

Sleep () {
	sleep=$(rand 4 40)
	echo "Sleeping for $sleep ticks."
	
	sleepthing=$(find "$_where" -iregex "$_where.*" | shuf | head -n1)
	sleepname=$(echo "$Item" | grep -o "[^/]*$" -- | sed -e "s/\..*$//g")

	message=$(mSleep)
}

Drop () {
	message="Mr Goosoo drops a cupcake at your feet."
	
	cps "./WORLD/Rec/Foods/Cupcake.prop" "$_where"
}


#START HERE
_oldwhere="$_where"
oldpw="$playerwhere"
playerwhere=$(cat "./DYNAMIC/p_where.txt" )
	
if [[ sleep -gt 0 ]]; then
	sleep=$((sleep-1))
	if [ "$playerwhere" = "$_where" ]; then
		if [[ "$oldpw" != "$_where" ]]; then
			message=${message:-$(mHereSleep)}
		else
			true
		fi
		echo Hi
	else
		if [ "$playerwhere" != "$_oldwhere" ]; then
			message=
		fi
	fi
	return
fi
A=$(rand 1 5)
#echo $A
case "$A" in
1|2)randdoor;;
3)Sleep;;
5)Drop;;
#7|8|9)Use;;
*)Wait;;
esac
#echo "	'$message'"
#echo "$playerwhere $_where" "$oldpw"
if [ "$playerwhere" = "$_where" ]; then
	if [[ "$oldpw" != "$_where" ]]; then
		message=${message:-$(mHere)}
	else
		true
	fi
	echo Hi
else
	if [ "$playerwhere" != "$_oldwhere" ]; then
		message=
	fi
fi
