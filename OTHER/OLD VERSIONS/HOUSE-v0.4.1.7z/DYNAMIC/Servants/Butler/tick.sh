#!/bin/bash

#Actions
#door () {

	##doors=$(find "$_where" -iname "*.door")
	#local mydoor=$(find "$_where" -iname "*.door" | shuf | head -n1 )
	#local doorname=$(echo "$Item" | grep -o "[^/]*$" -- | sed -e "s/\..*$//g")

	#if [ -e "$_where/Butler.ref" ]; then
	#echo "I'm Here: $_where"
	#else
	#echo "That was not expected."
	#find "./" -iname "Butler.ref"
	#_where=$(find "./" -iname "Butler.ref" | head -n1 | sed "s/Butler.ref//")
	#echo "$_where"
	#return
	#fi

	##echo "Doors:"
	##echo "$doors"

	#if [ "$doorname" = dir ]; then
		#echo "Dir Door"
		#return
	#fi
	
	#echo "Chosen Door: $mydoor"
	#propdoor=$(cprop "$mydoor" && echo Prop)

	#if [ ${propdoor:=non} = non ]; then
		#echo "Non-prop door"
		#doorgo=$(cat "$mydoor" | sed -e 's/\\/\//g')
		#echo "$doorgo"
	#else
		#echo "Prop door"
		#doorgo=$(qprop Where@Door "$mydoor" | sed -e 's/\\/\//g')
		#echo "$doorgo"
	#fi
	
	#if [ -e "$doorgo/Name.txt" ]; then
		#if [[ "$doorgo" =~ "WORLD/House/" ]]; then
			#echo "Valid Door!"
			#_where="$doorgo"
			#mv "$_oldwhere/Butler.ref" "$_where"
			
			#if [ "$playerwhere" = "$_where" ]; then message="$(come)"; fi
			#if [ "$playerwhere" = "$_oldwhere" ]; then message="$(leave)"; fi
		#else
			#echo "Door goes outside the house."
		#fi
	#else
		#echo "Nope! Shouldn't go there!"
	#fi
#}

HoldSomethingElse () {
	echo "Holding: $_handname"
	echo "Inventory:"
	find "$me/Inventory" -iregex "\./DYNAMIC/Servants/Butler/Inventory/.*"
	local _handtest=$(find "$me/Inventory" -iregex "\./DYNAMIC/Servants/Butler/Inventory/.*" | shuf | head -n1)
	if [ "$_handtest" != "$_hand" ]; then
		_hand="$_handtest"
		_handname=$(echo "$_hand" | grep -o "[^/]*$" -- | sed -e "s/\..*$//g")
		echo "Holding: $_handname"
		message="$(mHold)"
	else
		HoldSomethingElse
		return
	fi
}

HoldNothing () {
	if [ ${_hand:-null} != null ]; then
		echo "Holding Nothing."
		message="$(mUnhold)"
		_hand=
		_handname=
	fi
}

Use () {
	echo "Use."
	Iext=$(echo "$_hand" | grep -o "\.[^\.]*$" --)

	#echo "Using the $Iname."
	if [ "${Iext:=dir}" = ".sh" ]; then
		. "$_hand"
		return
	elif [ -d "$_hand" ]; then
		if [ -e "$_hand/Use.sh" ]; then
			. "./$_hand/Use.sh"
			return
		elif [ -e "$_hand/use.sh" ]; then
			. "./$_hand/use.sh"
			return
		fi
	fi

	echo "You can't use the $_handname!"
	
	HoldSomethingElse
}

Wait () {
	message=
}

_oldwhere="$_where"
oldpw="$playerwhere"
playerwhere=$(cat "./DYNAMIC/p_where.txt" )
	
A=$(rand 1 12)
#echo $A
case "$A" in
1|2|3)randdoor;;
5)HoldSomethingElse;;
6)HoldNothing;;
7|8|9|10)Use;;
*)echo "Waiting...";;
esac
#echo "	'$message'"
#echo "$playerwhere $_where" "$oldpw"
if [ "$playerwhere" = "$_where" ]; then
	if [[ "$oldpw" != "$_where" ]]; then
		message=${message:-$(mHere)}
	else
		true
	fi
	echo Hi
else
	if [ "$playerwhere" != "$_oldwhere" ]; then
		message=
	fi
fi

#sleep 3

#echo "tick">"$me/ctick"



