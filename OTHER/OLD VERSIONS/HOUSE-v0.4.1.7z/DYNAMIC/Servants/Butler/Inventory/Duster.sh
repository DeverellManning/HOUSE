#!/bin/bash

Item=$(find "$_where" -iregex "$_where.*" | shuf | head -n1)
Iname=$(echo "$Item" | grep -o "[^/]*$" -- | sed -e "s/\..*$//g")
	
message="The Butler dusts the $Iname."
