#!/bin/bash

message="The Butler sweeps the floor"
