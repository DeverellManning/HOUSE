#!/bin/bash

cd /home/deverell-manning/Public/HOUSE
me="./DYNAMIC/Servants/Butler"
_name="Butler"

_ptty="$(cat ./DYNAMIC/tty.id.txt)"
echo "$_ptty"

. "./PRGM/data/PropertyUtil.sh"
. "./PRGM/utility/RandomUtil.sh"
. "./PRGM/utility/FilesUtil.sh"

. "./PRGM/npc/DoorUtil.sh"


#Messages
mHere () {
	if [ ${_handname:-null} != null ]; then
	echo "The Butler is in here, holding a $_handname."
	else
	echo "The Butler is in here."
	fi
}
mLeave () {
	echo "The Butler leaves the room."
}
mCome () {
	if [ ${_handname:-null} = null ]; then
		echo "The Butler enters the room."
	else
		echo "The Butler enters the room, holding a $_handname."
	fi
}
mHold () {
	echo "The Butler takes his $_handname out of his pockets."
}
mUnhold () {
	echo "The Butler puts his $_handname back in his pockets."
}

echo "Welcome to Butler Live."
_where=$(cat "$me/Where")
_hand=
_handname=
allowedArea="WORLD/House/"

echo "rtest: $(rand 0 10)"

if [[ $(cat "$me/ctick" | tr [:upper:] [:lower:]) = auto ]]; then
	echo "AUTO BUTLER ENABLED."
	auto=t
else
	auto=f
fi
	

until [ "$Pin" = END ]
do
	Pin=$(cat "$me/ctick")

	echo "%$Pin%"

	if [[ "${Pin:-null}" = tick || "$auto" = t ]]; then
		time . "$me/tick.sh"
	fi
	
	if [ "${message:-null}" != null ]; then
		echo "	'$message'"
		tput il1>"$_ptty"; echo -ne "\e[0m$message\e[0m">"$_ptty"; tput cud1>"$_ptty"; tput el>"$_ptty"; tput el1>"$_ptty"; tput hpa 0>"$_ptty"; echo -ne "\e[96m> ">"$_ptty"
	fi
	message=

	sleep 0.02
done

echo "Saving:"

echo "$_where">"$me/Where"

