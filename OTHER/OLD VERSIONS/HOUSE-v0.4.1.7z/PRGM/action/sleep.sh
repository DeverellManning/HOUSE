#!/bin/bash

#Check if lying or sitting
#Check Quality of seat/bed

if [[ $1 = sleep ]]; then
	echo "Sleeping"
fi
_sleep=$_p1

_sleepc=./PRGM/action/sleep.sh sleep
