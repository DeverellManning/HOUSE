#!/bin/bash

Item="$_p1 $_p2"
Item=`echo $Item | sed -e 's/ *$//g'`

if [ "${Item:-null}" = "null" ]; then
	read -p "Use what? " Item
fi

_energy=$((_energy-1))

#ponfon "$Item"

Item="$(ponfon "$Item")"
Iname=$(echo "$Item" | grep -o "[^/]*$" -- | sed -e "s/\..*$//g")
Iext=$(echo "$Item" | grep -o "\.[^\.]*$" --)

#echo "Using the $Iname."
if [ "${Iext:=dir}" = ".sh" ]; then
	. "$Item"
	return
elif [ -d "$Item" ]; then
	if [ -e "$Item/Use.sh" ]; then
		. "./$Item/Use.sh"
		return
	elif [ -e "$Item/use.sh" ]; then
		. "./$Item/use.sh"
		return
	fi
fi

echo "You can't use the $Iname!"


