#!/bin/bash

prop="$_p1"

loc="`find "$_where"/"$_p2".* | head -n 1`"

#./PRGM/SHUB/Qprop.sh "$prop" "$loc"

value=`./PRGM/data/Qprop.sh "$prop" "$loc"`

sleep 0.5

echo -e "\n$value"

