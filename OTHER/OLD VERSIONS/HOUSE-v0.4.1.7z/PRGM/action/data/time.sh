#!/bin/sh

echo "Time: '$ttick' - $thour:$tminute, Day: $tDay"

./PRGM/output/Clock.sh "$thour" "$tminute"
