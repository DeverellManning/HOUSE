#!/bin/sh

echo WOPOOSHY
echo
echo "You just randomly teleport to Ardey!"
_where="./WORLD/Eligotextum/Ardey/Town/Street"
clein
./PRGM/action/look.sh
