#!/bin/bash

echo -e "$ChromaDebugInventory Path: $ppath/Inventory/"
#echo "Checking Existence of Inventory..."

if [ -d $ppath/Inventory ]; then
	echo
	echo -e "$ChromaInventory[4m  Inventory  [0m"
	echo -e "$ChromaInventoryCoins$ChromaInventory"
	echo -ne "Current: $_coins - "
	echo -n "Saved: "
	cat "$ppath/Wallet/Coins"
	echo
	echo "Inventory Content:"
	ls "./$ppath/Inventory" --quoting-style=literal -1

	echo -e $ChromaDefault
	#echo "Done!(For Now)"
	
else 
	echo "$_ChromaDefault Oh No! Your inventory apparently DOESN'T EXIST! Do YOU even exist?!"
	sleep 1

fi

