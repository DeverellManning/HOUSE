#!/bin/bash

Item="$_p1 $_p2"
Item=`echo $Item | sed -e 's/ *$//g'`

loc="`findinv "$Item" | head -n 1`"
if [[ ${loc:null} = null ]]; then
	loc="`findwhere "$Item" | head -n 1`"
	if [[ ${loc:null} = null ]]; then
		echo "There is no $Item here!"
	fi
fi

if [ "$(cprop "$loc" && echo true)" ]; then
	local edible=$(qprop edible@Food "$loc")
	if [ "$edible" != true ]; then
		echo "That food is bad.   Don't eat it!"
		return
	fi
	local nut=$(qprop nutrition@Food "$loc")
	local cal=$(qprop calories@Food "$loc")
	#echo "$nut $cal"
	
	local energyplus=$((cal - 9))
	local healthplus=$((nut/cal))
	healthplus=$(echo "$nut/$cal" | bc -l | grep -o "[0.9]*\.[0-9]")
	echo "$energyplus - $healthplus"
	
	if [ $_energybuffer -lt 1000 ]; then
		_energybuffer=$((_energybuffer + energyplus ))
	fi
	if [ $(echo "$_healthbuffer < 4" | bc) -eq 1 ]; then
		_healthbuffer=$(echo "$_healthbuffer + $healthplus" | bc)
	fi
	
	local waterplus=$(qprop water@Food "$loc")
	if [ ${waterplus:-null} = null ]; then true; else
		if [ $_waterbuffer -lt 8 ]; then
			_waterbuffer=$(( waterplus + _waterbuffer ))
		fi
	fi
	
	if [ -e "$loc" ]; then
		echo "Delete!"
		echo $loc
		rm -I "$loc"
	fi
	
else
	echo "You can't eat the $Item."
fi
