#!/bin/sh


Item="$_p1 $_p2"
Item=`echo $Item | sed -e 's/ *$//g'`

echo "Item: '$Item'"
if [ "${_target:-null}" != null ]; then 
	echo "Target: '$_target'"
fi

if [ "${Item:-null}" = null ]; then
	. ./PRGM/SH/inv.sh
	echo "You drop what?"
	read Item
fi




#Errors

NotExist () {
	echo "You do not have a $Item."
	return
}



DropToTarget () {
	Item=$(findinv "$Item" | shuf | head -n1)
	if [[ ${Item:-null} != null ]]; then
		echo $Item
		bitem=$(basename "$Item")
		mvs "$Item" "$_target"
	fi
	
	Itest=$(find "$_target" -maxdepth 1 -iregex ".*/$bitem" | head -n 1)
	if [ -e "$Itest" ]; then
		echo "Move Successful!"
		return
	fi
	
}

_energy=$((_energy-2))

if [ "${_target:-null}" != null ]; then
	DropToTarget
else
	echo "Moving item: $Item in inventory to $_where"
	
	IPath=$(find "$ppath/Inventory" -maxdepth 1 -iregex ".*/$Item.*\..*$" | head -n 1)
	echo "$IPath"
	
	if [ -e "$IPath" ]; then
			mvs "$IPath" "$_where"
			Itest=$(find "$_where" -maxdepth 1 -iregex ".*/$Item.*\..*$" | head -n 1)
			if [ -e "$Itest" ]; then
				echo "Move Successful!"
				return
			fi
	else
		IPath=$(find "$ppath/Inventory" -maxdepth 1 -iregex ".*/$Item.*$" | head -n 1)
		echo "$IPath"
		if [ -d "$IPath" ]; then
			mv "$IPath" "$_where"
			Itest=$(find "$_where" -maxdepth 1 -iregex ".*/$Item.*$" | head -n 1)
			if [ -e "$Itest" ]; then
				echo "Move Successful!"
				return
			fi
		fi
	fi
	echo "Move Unsuccessful!"
fi
