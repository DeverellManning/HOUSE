
#1. Start New NPC
#2. For every NPC...
#   a. Check if it's still in player's region
#   b. If it is, send tick
#   c. If it isn't send END

#Start new NPCs
chars=$(echo -e "$PCpaths" | xargs -I {} find "{}" -iname "*.char")
if [[ ! ${chars:-null} = null ]]; then
	nl=$(echo -e "$chars" | awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}')
	for cline in $(seq 1 $nl); do
		curchar="$(getLine "$chars" $cline)"
		curcharloc="$(< "$curchar")"
		if [ -e "${curcharloc}"/*.live.sh ]; then
			echo "Found NPC! - ${curcharloc} @ $curchar"
			if [[ ! $(echo $npcl | grep "${curcharloc}") ]]; then
				echo "Added"
				lxterminal -t "$(basename "${curcharloc}")" -e "bash ${curcharloc}"/*.live.sh
				npcl=$(echo -e "${npcl}\n${curcharloc}")
			fi
		fi
	done
fi


#Tick NPCs
nl=$(echo -e "$npcl" | awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}')
rl=$(echo -e "$PCregions" | awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}')

#echo "$nl - $rl"
for line in $(seq 1 $nl); do				#For every NPC...
	cl=$(getNPC $line)
	if [[ ${cl:-null} = null ]]; then continue; fi
	
	inregion=false
	NPCwhere=$(< "$cl/Where")
	NPCregion=$(PathToRegion "$NPCwhere")
	
	echo -e "\n+ $line $(basename "$cl") @ $NPCregion"

	for rline in $(seq 1 $rl); do			#For every active region...
		if [[ $NPCregion = $(getLine "$PCregions" $rline) ]]; then	
			#echo "Match!"
			inregion=true
			break
		fi
	done
	
	if $inregion; then
		echo "tick" > "$cl/ctick" &			#Tick if in region
		echo "ticking npc: $cl"
	else
		echo "END" > "$cl/ctick" &			#Otherwise, End the NPC
		temp=$(echo "$cl" | sed -e "s/\//./g")
		#echo $temp
		npcl=$(echo -e "$npcl" | sed -e "s/$temp//g")
		echo "Stopped npc: $cl"
	fi
done
