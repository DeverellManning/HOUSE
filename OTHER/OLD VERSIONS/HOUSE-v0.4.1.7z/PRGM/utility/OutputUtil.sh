#!/bin/bash

#Utility Functions for output

write () {
	echo -e $1
}

typewriter () {
		#TODO: Mode for Use in pipes, like 'write "Hello" | typewriter'
	echo -e $1
}

write_file () {
	cat $1
}

write-picture () {
	#TODO:
	#Check $TERM for Xterm
	#other stuff
	convert "$1" six:-
}
