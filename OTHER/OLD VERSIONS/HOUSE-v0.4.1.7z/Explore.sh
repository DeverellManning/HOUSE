#!/bin/bash


echo Starting

cd /home/deverell-manning/Public/HOUSE/
ls

bd=	#?

#---VARS---

#Function
#SET "_return="

_gameversion="0.3"
_tty="$(tty)"
echo "$_tty"
echo "$_tty">"./DYNAMIC/tty.id.txt"

##Parser
_ptest=false
_in=
_act=
_p1=
_p2=

#Colors
export ChromaTitle="\e[0m\e[4m\e[40m\e[95m"
export ChromaText="\e[0m"
export ChromaInventory="\e[0m\e[43m\e[37m\e[1m"
export ChromaDebug="\e[0m[1;31m[40m"
export ChromaError="\e[0m[1;31m[43m"
export ChromaDefault="\e[0m"

#Player
export ppath= #Player Path
export pname= #Player Folder Name

export _name=  #Player full name
export _sname= #Player short name
export _where=
export _lastwhere=
export _coins=
export _health=
export _target=

#History
hstloc=
hstmov=


#Time
export ttick=0
export tminute=0
export thour=0
export tDay=0

#Testing
_sleep=0

#Load Utilities
. "./PRGM/data/PropertyUtil.sh"
. "./PRGM/utility/FilesUtil.sh"
. "./PRGM/utility/RandomUtil.sh"
. "./PRGM/utility/OutputUtil.sh"

pause () {
	read -rN 1
}

quitwarn () {
  echo "Type QUIT in upper case to quit, if you really want too."
}

clein () {
	_act=
	_p1=
	_p2=
}


GameTick() {
	if [[ ! $_sleep -gt 0 ]]; then echo -e "$ChromaDefault"; fi

	echo -n "tick">"./DYNAMIC/tick"
	
	#Time
	ttick=`cat "./WORLD/Time.txt"`
	tminute=$(((ttick / 5)%30 * 2))
	thour=$((((ttick / 5) / 30)%24))
	tDay=$((((ttick / 5) / 30) / 24))

	#Player
	. "./PRGM/player/tick.sh"

	#Room Tree Ticking
	local tw="$_where"
	until [[ $tw = "." || $tw = "/" || ${tw:-null} = null ]]; do
		#echo "$tw/tick.sh"
		if [ -e "$tw/tick.sh" ]; then . "$tw/tick.sh"; fi
		tw=$(echo "$tw" | sed "s/\/[^\/]*$//")
	done

	#Previous Room Tree Ticking
	if [[ $_lastwhere != $_where ]]; then
		_target=
		if [[ -e ${_lastwhere}/${_name}.char ]]; then
			mv "${_lastwhere}/${_name}.char" "${_where}/${_name}.char"
		else
			echo "$ppath" > "${_where}/${_name}.char"
			echo "I fixed a problem with your body."
		fi
	fi
	
	#if $_MASTER; then echo -n "" > "./DYNAMIC/players.txt"; fi
	echo "$pname@$_where" >> "./DYNAMIC/players.txt"
	
	#Where Storage
	_lastwhere="$_where"
	

	#echo "Health: $_health, Health Buffer: $_healthbuffer, Max Health: $_maxhealth"
	#echo "Energy: $_energy, Energy Buffer: $_energybuffer, Max Energy: $_maxenergy"
	#echo "Time: $ttick - $tminute - $thour - $tDay"
	#echo "where: '$_where'"

	#if Sleeping/Skipping Turns, Skip Input
	if [ $_sleep -gt 0 ]; then
		#echo "Skip! $sleep"
		_sleep=$((_sleep - 1))
		
		. "$_sleepc"
		sleep 0.05
	else
		_sleep=0
		_sleepc=
		#Get Input		#read -rp"> " _act _p1 _p2
		echo -ne "\e[96m"
		read -erp"> " _in
		echo -e "\e[0m"
		
		#echo "$_in"
		if [ "$(echo "$_in" | tr "[:upper:]" "[:lower:]")" = "quit" ]; then
			quitwarn
		elif [ "${_in:-null}" = "null" ]; then
			return
		else
			. ./PRGM/parser/DirectClause.sh
			#. ./PRGM/parser/ActFind.sh #"$_act" "$_p1" "$_p2"		#This is important!
		fi
	fi
	

	#Wait for other player...
	#(Not Implemented)
	
}

mastertick () {	#Obsolete
	(echo tick>./PRGM/npc/ctick &)
}

StartMenu () {
	clear
	. ./PRGM/output/menu/StartMenu.sh
	
	_act=
	read -rp "Enter Name or Action:" _act
	_act=$(echo $_act | tr "[:upper:]" "[:lower:]")

	case "$_act" in
	q)
		echo "Goodbye."
		pause
		exit;;
		#Stop
	v)
		echo "Version: $_gameversion"
		echo "Press Enter"
		pause
		StartMenu;;
	n)
		echo New Character
		./PRGM/player/NewChar.sh
		sleep 2
		StartMenu;;
	c)
		echo "Change Log: WIP"
		##
		echo "Press Enter"
		pause
		StartMenu;;
	*)
		if [ -e "./DYNAMIC/Player/$_act/Where" ]; then
			ppath="./DYNAMIC/Player/"$_act
			pname=$_act
			. ./PRGM/player/LoadChar.sh

		else
			echo "./DYNAMIC/Player/$_act/where.txt"
			echo "That character does not exist!"
			echo "Press Enter"
			pause
			StartMenu
		fi;;
	esac
	_act=
	_in=



}

Stop () {
  echo "QUITING"
  sleep 0.6
  echo "Saving Data..."
  . ./PRGM/player/SaveChar.sh
  sleep 0.6
  echo "Goodbye!  Come back any time!"
}


#___START HERE___#
while true; do
pause
StartMenu

clear

#script -a -O ./OTHER/HouseScript.log
_MASTERname=$(cat ./DYNAMIC/master)
if [[ ${_MASTERname:-null} == null ]]; then
	echo "$ppath" > "./DYNAMIC/master"
	_MASTER=true
	lxterminal -e "./PRGM/master/master.sh"
	
	echo "This is the Master Proccess."
fi

echo "Welcome, $_name."
sleep 1
read -t 0.1
echo

. ./PRGM/action/data/where.sh
. ./PRGM/action/look.sh

until [ "$_in" = "QUIT" ];
do
	GameTick
	#if $_MASTER; then
	#	mastertick
	#fi
done

#Player has Quit,
#Clean up and return to start menu.
Stop
#Really, these things should go in master.sh, but leave echo "END"
if $_MASTER; then
	echo -n "" > "./DYNAMIC/players.txt" #Fix.  Remove entry from online.txt
	echo "END">"./DYNAMIC/tick"
	echo -n "" > "./DYNAMIC/master"
fi
done
