#!/bin/bash




#Vars
npcl=		#List of NPCs
ctick=		#Tick from Explore.sh

regionfile=$(cat ./WORLD/Region.txt)	#The file Region.txt
PCregions=								#Regions Occupied by PCs
PCpaths=								#Base Paths of Regions occupied by PC's
PCwheres=								#Locations of PCs


#Functions
getNPC () {
	echo -e "$npcl" | head -n$1 | tail -n1
}

getLine () {
	echo -e "$1" | head -n$2 | tail -n1
}

PathToRegion () {
	rl=$(echo -e "$regionfile" | awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}')
	for rline in $(seq 1 $rl); do
		cl=$(getLine "$regionfile" $rline)
		cl1=$(echo "$cl" | cut -c 1)
		if [[ $cl1 = \( ]]; then
			curname=$(echo "$cl" | sed -e "s/(//")
			#echo "( - New name: '$curname'"
			continue
		elif [[ $cl1 = \) ]]; then continue; fi
		
		#echo $cl
		
		if [[ $1 =~ $cl ]]; then
			echo "$curname"
			break;
		fi
	done
}

RegionToPaths () {
	rl=$(echo -e "$regionfile" | awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}')
	
	sl=$(echo -e "$regionfile" | grep -no "$1" | sed -e "s/:.*//" | head -n 1)
	#echo "Start: $sl End: $rl"
	
	for rline in $(seq "$sl" "$rl"); do
		#echo -n "$rline:"
		cl=$(getLine "$regionfile" $rline)
		#echo "$cl"
		cl1=$(echo "$cl" | cut -c 1)
		if [[ $cl1 = \( ]]; then
			#echo "( - Skipping '$cl'"
			continue;
		elif [[ $cl1 = \) ]]; then break; fi
		echo "$cl"
	done
	
	#echo "Done!"; 
}

##############
# START HERE #
##############
cd /home/deverell-manning/Public/HOUSE/





#Repeat Master Ticking
#Until END is sent from User
until [[ $ctick = END ]]; do

	sleep 1.5									#Wait 2 seconds
	ctick=
	until [[ ${ctick:-null} != null ]]; do		#Wait until any one does a turn
		ctick=$(< ./DYNAMIC/tick)
		sleep 1
	done
	
	echo -n "">"./DYNAMIC/tick"
	echo "%$ctick%"
	
	#Reset Some Variables
	PCwheres=$(cat ./DYNAMIC/players.txt | sed -e "s/[^@]*@//g")
	PCregions=
	PCpaths=
	
	echo "$PCwheres"
	#Load Region Variables
	nl=$(echo -e "$PCwheres" | awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}')
	for line in $(seq 1 $nl); do
		curRegion=$(PathToRegion "$(getLine "$PCwheres" $line)")
		PCregions=${PCregions}$curRegion
		#RegionToPaths "$curRegion"
		PCpaths=${PCpaths}$(RegionToPaths "$curRegion")
	done
	
	echo -e "Active Regions:\n'$PCregions'"
	echo -e "Paths of Active Regions:\n'$PCpaths'"
	echo "---"
	
	#Tick the Time
	ttick=$((ttick + 1))
	tminute=$(((ttick / 5)%30 * 2))
	thour=$((((ttick / 5) / 30)%24))
	tDay=$((((ttick / 5) / 30) / 24))
	
	#Tick the World
	. ./PRGM/master/world_tick.sh
	
	#Tick NPC Manager
	. ./PRGM/master/npc_tick.sh
	


	echo
	sleep 0.01
done


#End all NPCs
echo "Stopping All NPCs:"
for line in $(seq 1 $nl); do
	cl=$(getNPC $line)
	if [[ ${cl:-null} = null ]]; then continue; fi
	echo "END" > "$cl/ctick" &
	echo "Stopped npc: $cl"
done
echo "Done. Press Enter to close."
read -t 5 var

	
