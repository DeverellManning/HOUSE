#!/bin/bash

echo () {
	builtin echo "Hi! $1"
}

v1=Hi
v2=Hi


echo "JK $v1 + $v2"
