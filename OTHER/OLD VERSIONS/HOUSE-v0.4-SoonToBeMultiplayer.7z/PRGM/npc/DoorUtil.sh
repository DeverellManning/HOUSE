#!/bin/bash


getLine () {
	cat "$1" | head -n$2 | tail -n1
}

randdoor () {
	local mydoor=$(find "$_where" -iname "*.door" | shuf | head -n1 )
	local doorname=$(inam "$mydoor")

	if [ -e "$_where/${_name}.char" ]; then
		echo "I'm Here: $_where"
	else
		echo "That was not expected."
		find "./" -iname "${_name}.char"
		_where=$(find "./" -iname "${_name}.ref" | head -n1 | sed "s/${_name}.char//")
		echo "'$_where'"
		return
	fi

	echo "Chosen Door: $doorname ( at '$mydoor' )"
	
	if [[ "$mydoor" =~ [Dd]ir ]]; then													#Dir Door
		echo "Dir Door"
		nl=$(awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}' "$mydoor")
		cl="$(getLine "$mydoor" "$(rand 1 $nl)")"
		echo "$cl out of $nl"
		doorgo="$(echo "$cl" | sed -e "s/.*+//g" | sed -e "s/,//"  | sed -e 's/\\/\//g')"
		#echo "$cl" | sed -e "s/.*+//g" | sed -e "s/,//"  | sed -e 's/\\/\//g'
		#echo "$doorgo"
	else
		propdoor=$(cprop "$mydoor" && echo Prop)

		if [ ${propdoor:=non} = non ]; then												#Normal Door
			echo "Non-prop door"
			doorgo=$(cat "$mydoor" | sed -e 's/\\/\//g')
		else																			#Extended Door
			echo "Prop door"
			doorgo=$(qprop Where@Door "$mydoor" | sed -e 's/\\/\//g')
		fi
	fi
	
	echo "Goes to: '$doorgo'"
	if [ ! -e "$doorgo/Name.txt" ]; then echo "Nope! Shouldn't go there!"; return; fi
	if [ ! -e "$(find "$doorgo" -iregex ".*\.door" | head -n 1)" ]; then echo "Nope! Shouldn't go there!"; return; fi
	if [[ ${allowedArea:-null} = null || $doorgo =~ $allowedArea ]]; then
			echo "Valid Door!"
			_where="$doorgo"
			echo "$_where" > "$me/Where"
			mv "$_oldwhere/${_name}.char" "$_where"
			
			if [ "$playerwhere" = "$_where" ]; then message="$(mCome)"; fi
			if [ "$playerwhere" = "$_oldwhere" ]; then message="$(mLeave)"; fi
			
	else
		echo "Nope! Not allowed there!"
	fi
}
