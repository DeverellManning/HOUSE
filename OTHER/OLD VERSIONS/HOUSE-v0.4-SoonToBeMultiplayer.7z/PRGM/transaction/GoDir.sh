#!/bin/sh

echo "Dir Door"

getLine () {
	cat "$1" | head -n$2 | tail -n1
}

ErrorMissingRoom () {
	echo "GoDir: The door is broken.  You can't go through it, because it goes nowhere."
}

BaseDoor () {
	test="$1" #Where the door goes to
	
	if [ -e "$test/Name.txt" ]; then				#Check Door Validity
		echo "You $v_walk through the door, to the"	
		 _where="$1"
		 clein
		. PRGM/action/look.sh
	else
		ErrorMissingRoom
	fi
}

DirDoor () {
	_energy=$((_energy-1))
	local Dir="$1"
	case $Dir in
		N|S|E|W)
			true;;
		NE|NW|SE|SW)
			true;;
		NORTH) Dir=N;;
		EAST) Dir=E;;
		SOUTH) Dir=S;;
		WEST) Dir=W;;
		NORTHEAST) Dir=NE;;
		NORTHWEST) Dir=NW;;
		SOUTHEAST) Dir=SE;;
		SOUTHWEST) Dir=SW;;
		IN|OUT)true;;
		DOWN|UP)true;;
	esac
	#echo :"Dir: '$Dir'"

	nl=$(awk 'BEGIN {count=0; OFS=" "} {count++} END {print count}' "$dirdoor")
	
	for N in $(seq 1 "$nl")
	do
		cl=$(getLine "$dirdoor" "$N")
		if [ "$(echo "$cl" | sed -e "s/+.*//g" | tr [a-z] [A-Z])" = "$Dir" ]; then
			#echo $cl
			local test
			test="$(echo "$cl" | sed -e "s/.*+//g" | sed -e "s/,//"  | sed -e 's/\\/\//g')"
			#echo "$test"
			BaseDoor "$test"
			return
		fi
	done

	echo "You can not go that way."
	cat "$dirdoor"
	#cat "$_where/Dir.door" | xargs -n 1 Test
}


if [ -e "$_where/Dir.door" ]
then
	dirdoor="$_where/Dir.door"
	sed -i -e 's/\r//g' "$_where/Dir.door"
	Item="$_act $_p1 $_p2"
	Item=$(echo "$Item" | sed -e 's/ *$//g' | tr [a-z] [A-Z] | sed -e "s/-//g")
	DirDoor "$Item"
elif [ -e "$_where/dir.door" ]; then
	dirdoor="$_where/dir.door"
	sed -i -e 's/\r//g' "$_where/dir.door"
	Item="$_act $_p1 $_p2"
	Item=$(echo "$Item" | sed -e 's/ *$//g' | tr [a-z] [A-Z] | sed -e "s/-//g")
	DirDoor "$Item"
else
	echo "You can not go that way. (2)"
fi
