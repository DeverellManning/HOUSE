#!/bin/sh

rand () {
	shuf -e $(seq "$1" "$2") | head -n1
}
