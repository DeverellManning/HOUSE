#!/bin/sh

Item="$_p1 $_p2"
Item=`echo $Item | sed -e 's/ *$//g'`

#echo "Item: '$Item'"
if [ "${_target:-null}" != null ]; then 
	echo "Target: '$_target'"
fi

weight=0

if [ "${Item:-null}" = null ]; then 
	echo "You take what?"
	read Item
fi

#Errors
TooHeavy () {
	echo "The $Iname is Too Heavy to Pick up, because it wieghs $weight!"
	return 1
}

Weightless () {
	echo "The $Iname is weightless, and therefore, very hard to hold."
	return 1
}

NotExist () {
	echo "There is no $dirobj here."
	return 1
}



weightT () {
	if [ ${weight:=0} -eq 0 ];then Weightless; return;fi
	echo "The $Iname has a weight of: $weight"
	if [ "$weight" -eq -1 ]; then Weightless;return; fi
	if [ "$weight" -gt 10 ]; then TooHeavy;return; fi
	
	_energy=$((_energy-weight))
	#echo "Moving item: '$Item'  to '$ppath/Inventory/"

mvs "$Item" "$ppath/Inventory/"
echo "$Ifull"
local Message="You pick up the $Iname and put it into your deep pockets."
#type "$ppath/Inventory/$Iname$Iext"
if [ -e "$ppath/Inventory/$Ifull" ]; then
	echo "$Message"
elif [ -e "$ppath/Inventory/$Iname*" ]; then
	echo "$Message"
else
	echo "Move Unsuccessful!"
fi
	
}

TakeFromTarget () {
	#find "$_target" -maxdepth 1 -iregex ".*$_target/\.?$1[^/]*$" #".*$_target/\.?$1[^/]*$"
	local out="$(findtarget "$1" | head -n 1)"
	if [ "${out:-null}" = "null" ]; then
		out="$(find "$_target/" -maxdepth 1 -iregex ".*/$1[^\./]*$" | head -n 1)"
	fi
	Item="$out"
	
	Iname=$(inam "$Item")
	Iext=$(echo "$Item" | grep -o "\.[^\.]*$" --)
	Ifull=$(echo "$Item" | grep -o "\.[^\]*$" --)

	echo "$Iname | $Iext"
	if [ -d "$Item" ]; then		#Is a Directory
	#echo "$Item is a Directory"
	if [ -e "$Item/Weight.txt" ]; then
		weight=`cat "$Item/Weight.txt"`
		weightT
	fi
	if [ -e "$Item/weight.txt" ]; then
		weight=`cat "$Item/weight.txt"`
		weightT
	fi
elif [ -f "$Item" ]; then
	cprop "$Item" && weight=`qprop weight@Prop "$Item"` && weightT || Weightless
else
	NotExist
fi
}




if [ "${_target:-null}" != null ]; then
	TakeFromTarget $Item
else

#echo "$_where/$Item"
Item=$(ponfon "$Item")

Iname=`echo "$Item" | grep -o "[^/]*$" -- | sed -e "s/\..*$//g"`
Iext=$(echo "$Item" | grep -o "\.[^\.]*$" --)

#echo "$Iname"
echo "$Iext"

if [ -d "$Item" ]; then		#Is a Directory
	#echo "$Item is a Directory"
	if [ -e "$Item/Weight.txt" ]; then
		weight=`cat "$Item/Weight.txt"`
		weightT
	fi
	if [ -e "$Item/weight.txt" ]; then
		weight=`cat "$Item/weight.txt"`
		weightT
	fi
elif [ -f "$Item" ]; then
	cprop "$Item" && weight=`qprop weight@Prop "$Item"` && weightT || Weightless
else
	NotExist
fi

fi
