#!/bin/sh
. ./PRGM/SH/door.sh
