#!/bin/sh
echo "You are at $_where"
