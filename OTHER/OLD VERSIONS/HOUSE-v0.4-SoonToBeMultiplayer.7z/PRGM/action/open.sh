#!/bin/bash

test="$_p1 $_p2"
test=$(echo "$test" | sed -e 's/ *$//g')

test=$(ponfon "$test")
echo "You open the $(inam "$_target")."

if [ -e "$test/Container.txt" ]; then
	_target=$test
	echo "In the $(inam "$_target"), there are:"
	./PRGM/output/ListContent.sh "$_target"
else
	echo "$test is not a container"
fi

echo "target is $_target"
echo "I LOVE YOU DALLEN!!!"
test=
