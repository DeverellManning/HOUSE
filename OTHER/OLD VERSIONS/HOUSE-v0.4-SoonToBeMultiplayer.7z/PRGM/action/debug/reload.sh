#!/bin/bash

. "./PRGM/data/PropertyUtil.sh"
. "./PRGM/utility/FilesUtil.sh"
. "./PRGM/utility/RandomUtil.sh"